﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Автор Rom Nosk, Курс C# Часть 2, Урок 4, Домашнее задание 18.11.19
// Выполнены задания 2 a),b),c); 3a)

namespace RomNosk_CPart2_L4_HW
{
    //Задание 2а) Дана коллекция List<T>, требуется подсчитать, сколько раз каждый элемент встречается в
    //данной коллекции для целых чисел;
    class Task2A
    {
        // Метод, подсчитывающий количество вхождений элемента _element в целочисленную коллекцию _intList
        public int NumbOfIntElementOccur(int element, List<int> intList)
        {
            int count = 0;
            foreach (int el in intList)
            {
                if (el == element) count++;
            }
            return count;
        }

        //Демонстрация выполнения задания
        public void Do()
        {
            List<int> intList = new List<int> { 1, 2, 3, 4, 3, 3, 2, 4, 4 }; // Тестовая целочисленная коллекция
            int element = 4;
            Console.WriteLine($"Элемент {element} встречается в коллекции {NumbOfIntElementOccur(element, intList)} раз");
            Console.Write("Жду нажатия клавиши..."); Console.ReadKey();
        }

    }//Task2A

    //Задание 2b) Дана коллекция List<T>, требуется подсчитать, сколько раз каждый элемент встречается в
    //данной коллекции для обобщённой коллекции;
    class Task2B
    {
        public delegate int Compare<T>(T item1, T item2);

        // Метод, подсчитывающий количество вхождений элемента element в коллекцию ourList произвольного типа T
        public int NumbOfElementOccur<T>(T element, List<T> ourList, Compare<T> Cmpr)
        {
            int count = 0;
            foreach (T el in ourList)
            {
                if (Cmpr(el, element) == 0) count++;
            }
            return count;
        }

        // Сравнивает два целых числа - для демонстрации работы метода поиска в обобщённой коллекции
        public int CompareInt(int a, int b)
        {
            if (a > b) return 1;
            else if (a == b) return 0; else return -1;
        }

        //Демонстрация выполнения задания
        public void Do()
        {
            List<int> intList = new List<int> { 1, 2, 3, 4, 3, 3, 2, 4, 4 }; // Тестовая целочисленная коллекция
            int element = 2;
            Console.WriteLine($"Элемент {element} встречается в коллекции {NumbOfElementOccur(element, intList, CompareInt)}раз");
            element = 3;
            Console.WriteLine($"Элемент {element} встречается в коллекции {NumbOfElementOccur(element, intList, CompareInt)}раз");
            Console.Write("Жду нажатия клавиши..."); Console.ReadKey();
        }
    }//Task2B

    //Задание 2c) Дана коллекция List<T>, требуется подсчитать, сколько раз каждый элемент встречается в
    //данной коллекции с использованием Linq;
    class Task2C
    {
        public delegate int Compare<T>(T item1, T item2);

        // Метод, подсчитывающий количество вхождений элемента element в коллекцию ourList произвольного типа T
        public int NumbOfElementOccur<T>(T element, List<T> ourList, Compare<T> Cmpr)
        {
            int count = 0;
            var linqList = from el in ourList where Cmpr(el, element) == 0 select el;
            foreach (T item in linqList) count++;
            return count;
        }

        // Сравнивает два целых числа - для демонстрации работы метода поиска в обобщённой коллекции
        public int CompareInt(int a, int b)
        {
            if (a > b) return 1;
            else if (a == b) return 0; else return -1;
        }

        //Демонстрация выполнения задания
        public void Do()
        {
            List<int> intList = new List<int> { 1, 2, 3, 4, 3, 3, 2, 4, 4, 4 }; // Тестовая целочисленная коллекция
            int element = 4;
            Console.WriteLine($"Элемент {element} встречается в коллекции {NumbOfElementOccur(element, intList, CompareInt)} раз");
            Console.Write("Жду нажатия клавиши..."); Console.ReadKey();
        }
    }//Task2C

    // Задание 3a) Свернуть обращение к OrderBy с использованием лямбда-выражения.
    class Task3A
    {
        //Демонстрация выполнения задания
        public void Do()
        {
            Dictionary<string, int> dict = new Dictionary<string, int>()
                {
                    { "four" , 4 },
                    { "two" , 2 },
                    { "one" , 1 },
                    { "three" , 3 },
                };
            //Исходное обращение к OrderBy 
            //var d = dict.OrderBy(delegate (KeyValuePair<string, int> pair) { return pair.Value; });

            //обращение к OrderBy, свёрнутое с помощью лямбда-выражения
            var d = dict.OrderBy(pair => pair.Value);

            foreach (var pair in d) Console.WriteLine("{0} - {1}", pair.Key, pair.Value);
            Console.Write("Жду нажатия клавиши..."); Console.ReadKey();
        }
    }// Task3A

    class Program
    {
        static void Main(string[] args)
        {
            //Task2A task2A = new Task2A();
            //task2A.Do();

            //Task2B task2B = new Task2B();
            //task2B.Do();

            //Task2C task2C = new Task2C();
            //task2C.Do();

            Task3A task3A = new Task3A();
            task3A.Do();
        }
    }
}

